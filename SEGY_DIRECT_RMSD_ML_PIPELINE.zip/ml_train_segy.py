
import numpy as np
from segy_io import read_segy
from sklearn.ensemble import RandomForestClassifier
import joblib, sys

inp, model_out = sys.argv[1], sys.argv[2]

data, dt = read_segy(inp)
X, y = [], []

for tr in data:
    d1 = np.gradient(tr)
    d2 = np.gradient(d1)
    for i in range(len(tr)):
        X.append([tr[i], abs(tr[i]), d1[i], d2[i]])
        y.append(1 if tr[i] < 0 else 0)

rf = RandomForestClassifier(n_estimators=200, random_state=0)
rf.fit(X, y)
joblib.dump(rf, model_out)
