
import numpy as np
from segy_io import read_segy, write_segy
import joblib, sys

inp, model_file, out = sys.argv[1], sys.argv[2], sys.argv[3]

data, dt = read_segy(inp)
rf = joblib.load(model_file)
outdata = data.copy()

for i in range(data.shape[0]):
    tr = data[i]
    d1 = np.gradient(tr)
    d2 = np.gradient(d1)
    for j in range(len(tr)):
        feat = [[tr[j], abs(tr[j]), d1[j], d2[j]]]
        if tr[j] > 0 and rf.predict(feat)[0] == 1:
            outdata[i, j] *= -1

write_segy(inp, out, outdata)
