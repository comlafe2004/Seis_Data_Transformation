
import numpy as np
from segy_io import read_segy, write_segy
from scipy.signal import find_peaks
import sys

inp, out = sys.argv[1], sys.argv[2]

data, dt = read_segy(inp)
ntr, ns = data.shape

rmsds = []
for tr in data:
    pos = tr[tr > 0]
    if len(pos) > 0:
        mu = pos.mean()
        rmsds.append(np.sqrt(((pos - mu)**2).mean()))
    else:
        rmsds.append(0.0)

RMSDmax = max(rmsds)
outdata = data.copy()

for i in range(ntr):
    tr = data[i]
    peaks, _ = find_peaks(tr, height=0)
    for p1, p2 in zip(peaks[:-1], peaks[1:]):
        seg = tr[p1:p2]
        if len(seg) > 0 and np.all(seg > 0):
            mask = seg <= RMSDmax
            outdata[i, p1:p2][mask] *= -1

write_segy(inp, out, outdata)
