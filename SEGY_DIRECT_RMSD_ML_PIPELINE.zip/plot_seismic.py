
import numpy as np
import matplotlib.pyplot as plt
from segy_io import read_segy
import sys

inp = sys.argv[1]
data, dt = read_segy(inp)

plt.imshow(data.T, cmap='seismic', aspect='auto')
plt.colorbar(label='Amplitude')
plt.xlabel('Trace')
plt.ylabel('Sample')
plt.title('Seismic Section')
plt.show()
