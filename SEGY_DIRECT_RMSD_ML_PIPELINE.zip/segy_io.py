
import segyio
import numpy as np

def read_segy(filename):
    with segyio.open(filename, "r", ignore_geometry=True) as f:
        data = segyio.tools.cube(f)[0]
        dt = segyio.tools.dt(f) / 1000.0
    return data, dt

def write_segy(reference, outname, data):
    with segyio.open(reference, "r", ignore_geometry=True) as f:
        spec = segyio.spec()
        spec.sorting = f.sorting
        spec.format = f.format
        spec.samples = f.samples
        spec.tracecount = data.shape[0]
        with segyio.create(outname, spec) as fo:
            fo.text[0] = f.text[0]
            for i in range(data.shape[0]):
                fo.trace[i] = data[i]
