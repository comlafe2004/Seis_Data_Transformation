
SEGY-DIRECT RMSD / ML POLARITY TRANSFORMATION PIPELINE
=====================================================

This package implements seismic polarity transformation directly on SEG-Y data.

CONTENTS
--------
- segy_io.py
- rule_transform_segy.py
- ml_train_segy.py
- ml_proxy_transform_segy.py
- plot_seismic.py

REQUIREMENTS
------------
numpy, scipy, matplotlib, scikit-learn, segyio
