import numpy as np
import matplotlib.pyplot as plt

def amp_spectrum(data, dt_ms):
    spec = np.abs(np.fft.rfft(data, axis=0))
    freq = np.fft.rfftfreq(data.shape[0], d=dt_ms/1000)
    return freq, spec.mean(axis=1)

if __name__ == "__main__":
    orig = np.loadtxt("data.txt")
    rule = np.loadtxt("rule.txt")
    ml   = np.loadtxt("ml.txt")

    f, so = amp_spectrum(orig, 4)
    _, sr = amp_spectrum(rule, 4)
    _, sm = amp_spectrum(ml, 4)

    plt.plot(f, so, label="Original")
    plt.plot(f, sr, label="Rule")
    plt.plot(f, sm, label="ML")
    plt.legend()
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("Amplitude")
    plt.savefig("amplitude_spectra.png", dpi=300)
