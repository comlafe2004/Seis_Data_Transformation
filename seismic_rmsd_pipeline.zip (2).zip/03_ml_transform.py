"""
ML transformation trained from rule flips
"""

import numpy as np
import argparse
import joblib
from sklearn.ensemble import RandomForestClassifier
from 02_rule_transform import rule_transform, global_rmsd_max

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default="ml.txt")
    ap.add_argument("--model", default="rf_model.joblib")
    args = ap.parse_args()

    data = np.loadtxt(args.input)
    rule_out, rmsd_max = rule_transform(data)

    X, y = [], []
    for k in range(data.shape[1]):
        for i in range(data.shape[0]):
            amp = data[i, k]
            X.append([amp, amp > 0, amp <= rmsd_max])
            y.append(int(rule_out[i, k] != data[i, k]))

    clf = RandomForestClassifier(
        n_estimators=300,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1
    )
    clf.fit(X, y)
    joblib.dump(clf, args.model)

    out = data.copy()
    idx = 0
    for k in range(data.shape[1]):
        for i in range(data.shape[0]):
            if clf.predict([X[idx]])[0]:
                out[i, k] *= -1
            idx += 1

    np.savetxt(args.output, out, fmt="%.6f")
    print("[OK] ML transform complete")
