"""
Generate full seismic plot suite
Rows = samples, Columns = traces
"""

import argparse
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def robust_limits(a, lo=1, hi=99):
    p1 = np.percentile(a, lo)
    p99 = np.percentile(a, hi)
    s = max(abs(p1), abs(p99))
    return -s, s

def imshow_save(arr, title, fname, time_ms, cmap, vmin, vmax):
    nt, ntr = arr.shape
    extent = [0, ntr-1, time_ms[-1], time_ms[0]]

    plt.figure(figsize=(7,5), dpi=150)
    plt.imshow(arr, aspect="auto", cmap=cmap,
               vmin=vmin, vmax=vmax, extent=extent)
    plt.colorbar(label="Amplitude")
    plt.xlabel("Trace index")
    plt.ylabel("Time (ms)")
    plt.title(title)
    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

def side_by_side(a, b, title_a, title_b, fname, time_ms, vmin, vmax):
    nt, ntr = a.shape
    extent = [0, ntr-1, time_ms[-1], time_ms[0]]

    fig, axs = plt.subplots(1,2, figsize=(10,5), dpi=150)
    axs[0].imshow(a, aspect="auto", cmap="seismic",
                  vmin=vmin, vmax=vmax, extent=extent)
    axs[1].imshow(b, aspect="auto", cmap="seismic",
                  vmin=vmin, vmax=vmax, extent=extent)

    axs[0].set_title(title_a)
    axs[1].set_title(title_b)

    for ax in axs:
        ax.set_xlabel("Trace index")
        ax.set_ylabel("Time (ms)")

    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

def difference(a, b, title, fname, time_ms):
    d = b - a
    vmin, vmax = robust_limits(d)
    imshow_save(d, title, fname, time_ms, "seismic", vmin, vmax)

def wiggle_plot(data, time_ms, fname):
    nt, ntr = data.shape
    gain = 1.0 / (np.max(np.abs(data)) + 1e-12)
    spacing = 1.5

    plt.figure(figsize=(7,9), dpi=150)
    for i in range(ntr):
        tr = data[:, i] * gain
        x = i*spacing + tr
        plt.plot(x, time_ms, color="black", linewidth=0.5)
        plt.fill_betweenx(time_ms, i*spacing, x,
                          where=(tr < 0), color="black", alpha=0.6)

    plt.gca().invert_yaxis()
    plt.xlabel("Trace index")
    plt.ylabel("Time (ms)")
    plt.title("Wiggle Variable-Area Plot (Original)")
    plt.tight_layout()
    plt.savefig(fname, dpi=300)
    plt.close()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--orig", required=True)
    ap.add_argument("--rule", required=True)
    ap.add_argument("--ml", required=True)
    ap.add_argument("--proxy", required=True)
    ap.add_argument("--dt-ms", type=float, default=4.0)
    ap.add_argument("--outdir", default="plots")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    orig  = np.loadtxt(args.orig)
    rule  = np.loadtxt(args.rule)
    ml    = np.loadtxt(args.ml)
    proxy = np.loadtxt(args.proxy)

    nt, ntr = orig.shape
    time_ms = np.arange(nt) * args.dt_ms

    vmin, vmax = robust_limits(orig)

    # Individual sections
    imshow_save(orig,  "Original (color)", f"{args.outdir}/original_color.png", time_ms, "seismic", vmin, vmax)
    imshow_save(orig,  "Original (B/W)",   f"{args.outdir}/original_bw.png",    time_ms, "gray",     vmin, vmax)
    imshow_save(rule,  "Rule (color)",     f"{args.outdir}/rule_color.png",     time_ms, "seismic", vmin, vmax)
    imshow_save(rule,  "Rule (B/W)",       f"{args.outdir}/rule_bw.png",        time_ms, "gray",     vmin, vmax)
    imshow_save(ml,    "ML (color)",       f"{args.outdir}/ml_color.png",       time_ms, "seismic", vmin, vmax)
    imshow_save(ml,    "ML (B/W)",         f"{args.outdir}/ml_bw.png",          time_ms, "gray",     vmin, vmax)
    imshow_save(proxy, "ML-Proxy (color)", f"{args.outdir}/proxy_color.png",    time_ms, "seismic", vmin, vmax)
    imshow_save(proxy, "ML-Proxy (B/W)",   f"{args.outdir}/proxy_bw.png",       time_ms, "gray",     vmin, vmax)

    # Side-by-side
    side_by_side(orig, rule, "Original", "Rule",
                 f"{args.outdir}/compare_orig_rule.png", time_ms, vmin, vmax)
    side_by_side(orig, ml,   "Original", "ML",
                 f"{args.outdir}/compare_orig_ml.png", time_ms, vmin, vmax)
    side_by_side(rule, ml,   "Rule", "ML",
                 f"{args.outdir}/compare_rule_ml.png", time_ms, vmin, vmax)

    # Differences
    difference(orig, rule, "Rule − Original",
               f"{args.outdir}/diff_rule_minus_orig.png", time_ms)
    difference(orig, ml,   "ML − Original",
               f"{args.outdir}/diff_ml_minus_orig.png", time_ms)
    difference(rule, ml,   "ML − Rule",
               f"{args.outdir}/diff_ml_minus_rule.png", time_ms)

    # Fraction flipped vs time (rule)
    flipped = (rule != orig)
    frac = flipped.sum(axis=1) / ntr
    df = pd.DataFrame({"time_ms": time_ms, "fraction_flipped": frac})
    df.to_csv(f"{args.outdir}/fraction_flipped_vs_time.csv", index=False)

    plt.figure(figsize=(8,4), dpi=150)
    plt.plot(time_ms, frac)
    plt.xlabel("Time (ms)")
    plt.ylabel("Fraction flipped")
    plt.title("Fraction flipped vs time (Rule)")
    plt.grid(True, linewidth=0.3)
    plt.tight_layout()
    plt.savefig(f"{args.outdir}/fraction_flipped_vs_time.png", dpi=300)
    plt.close()

    # Wiggle
    wiggle_plot(orig, time_ms,
                f"{args.outdir}/wiggle_variable_area_original.png")

    print("[OK] All plots generated")

if __name__ == "__main__":
    main()
