"""
RMSD-based rule transformation
"""

import numpy as np
from scipy.signal import find_peaks
import argparse

def rmsd_positive(trace):
    pos = trace[trace > 0]
    if pos.size == 0:
        return 0.0
    mu = pos.mean()
    return np.sqrt(np.mean((pos - mu) ** 2))

def global_rmsd_max(data):
    return max(rmsd_positive(data[:, k]) for k in range(data.shape[1]))

def rule_transform(data):
    out = data.copy()
    rmsd_max = global_rmsd_max(data)

    for k in range(data.shape[1]):
        tr = data[:, k]
        peaks, _ = find_peaks(tr, height=0)

        for i in range(len(peaks) - 1):
            s, e = peaks[i], peaks[i+1]
            segment = tr[s:e+1]

            if np.all(segment > 0) and np.any(segment <= rmsd_max):
                out[s:e+1, k][segment <= rmsd_max] *= -1

    return out, rmsd_max

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default="rule.txt")
    args = ap.parse_args()

    data = np.loadtxt(args.input)
    out, rmsd_max = rule_transform(data)
    np.savetxt(args.output, out, fmt="%.6f")

    print("Global RMSD_max =", rmsd_max)
