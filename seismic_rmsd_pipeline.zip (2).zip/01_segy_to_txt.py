"""
Convert SEG-Y to ASCII matrix
Rows = samples, Columns = traces
"""

import segyio
import numpy as np
import argparse
import os

def segy_to_txt(segy_path, out_txt, fraction=1.0):
    if not os.path.exists(segy_path):
        raise FileNotFoundError(segy_path)

    with segyio.open(segy_path, "r", ignore_geometry=True) as f:
        f.mmap()
        n_traces = f.tracecount
        n_use = int(n_traces * fraction)
        n_samples = len(f.trace[0])

        data = np.zeros((n_samples, n_use))
        for i in range(n_use):
            data[:, i] = f.trace[i]

    os.makedirs(os.path.dirname(out_txt), exist_ok=True)
    np.savetxt(out_txt, data, fmt="%.6f")

    print(f"[OK] SEG-Y → TXT")
    print(f"Samples × Traces = {data.shape}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-segy", required=True)
    ap.add_argument("--output-txt", required=True)
    ap.add_argument("--fraction", type=float, default=1.0)
    args = ap.parse_args()

    segy_to_txt(args.input_segy, args.output_txt, args.fraction)
