"""
ML-proxy (median filter)
"""

import numpy as np
import argparse
from scipy.signal import medfilt

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", default="ml_proxy.txt")
    ap.add_argument("--kernel", type=int, default=5)
    args = ap.parse_args()

    data = np.loadtxt(args.input)
    out = medfilt(data, kernel_size=(args.kernel, 1))
    np.savetxt(args.output, out, fmt="%.6f")

    print("[OK] ML-proxy transform complete")
