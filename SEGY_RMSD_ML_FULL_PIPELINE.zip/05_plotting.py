import numpy as np
import matplotlib.pyplot as plt

def plot_section(data, title, dt=0.004):
    t = np.arange(data.shape[1]) * dt
    plt.imshow(data.T, cmap="seismic", aspect="auto",
               extent=[0, data.shape[0], t[-1], t[0]])
    plt.colorbar(label="Amplitude")
    plt.title(title)
    plt.xlabel("Trace")
    plt.ylabel("Time (s)")
    plt.show()
