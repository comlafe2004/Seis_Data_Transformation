SEGY DIRECT RMSD / ML POLARITY TRANSFORMATION PIPELINE

Scripts:
01_segy_to_txt.py           Convert SEGY to TXT
02_rule_transformation.py   Deterministic RMSD rule
03_ml_transformation.py     ML training
04_ml_proxy_transformation.py ML proxy application
05_plotting.py              Visualization utilities
