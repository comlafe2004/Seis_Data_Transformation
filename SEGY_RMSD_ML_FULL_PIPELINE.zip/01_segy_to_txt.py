import segyio
import numpy as np

def segy_to_txt(segy_file, out_txt):
    with segyio.open(segy_file, "r", ignore_geometry=True) as f:
        data = segyio.tools.cube(f)
        data2d = data.reshape(data.shape[0], -1)
        np.savetxt(out_txt, data2d, fmt="%.6e")

if __name__ == "__main__":
    segy_to_txt("input.sgy", "output.txt")
