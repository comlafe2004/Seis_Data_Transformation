import numpy as np

def rmsd_rule_transform(data):
    out = data.copy()
    for i in range(data.shape[0]):
        trace = data[i]
        pos = trace[trace > 0]
        if len(pos) == 0:
            continue
        rmsd = np.sqrt(np.mean((pos - np.mean(pos))**2))
        mask = (trace > 0) & (trace <= rmsd)
        out[i, mask] *= -1
    return out

if __name__ == "__main__":
    data = np.loadtxt("output.txt")
    out = rmsd_rule_transform(data)
    np.savetxt("rule_transformed.txt", out, fmt="%.6e")
