import numpy as np
from joblib import load

def extract_features(trace):
    d1 = np.gradient(trace)
    d2 = np.gradient(d1)
    return np.vstack([trace, np.abs(trace), d1, d2]).T

def apply_ml_proxy(data, model_file):
    model = load(model_file)
    out = data.copy()
    for i in range(data.shape[0]):
        feats = extract_features(data[i])
        preds = model.predict(feats)
        out[i, preds == 1] *= -1
    return out
