import numpy as np
from sklearn.ensemble import RandomForestClassifier

def extract_features(trace):
    d1 = np.gradient(trace)
    d2 = np.gradient(d1)
    return np.vstack([trace, np.abs(trace), d1, d2]).T

def train_ml(data, labels):
    X, y = [], []
    for i in range(data.shape[0]):
        X.append(extract_features(data[i]))
        y.append(labels[i])
    X = np.vstack(X)
    y = np.hstack(y)
    rf = RandomForestClassifier(n_estimators=200, random_state=42)
    rf.fit(X, y)
    return rf
